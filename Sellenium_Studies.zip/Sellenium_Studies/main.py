from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

import time


# CARREGAR UMA PÁGINA NO CHROME
'''
driver = webdriver.Chrome(executable_path = r'./chromedriver.exe')
driver.get('https://www.devaprender.com')
driver.close()
'''

# FUNÇÕES AUXILIARES

def SignInFacebook():

    site = 'https://www.facebook.com/'
    login = 'otaviowoiciekowski@gmail.com'
    password = 'Eistein1906!'

    driver = webdriver.Chrome(executable_path = r'./chromedriver.exe')              # entra com o que executa
    driver.get(site)                                                                # entra com o executor

    usuario = driver.find_element_by_id('email')
    usuario.send_keys(login)
    usuario = driver.find_element_by_id('pass')
    usuario.send_keys(password)
    time.sleep(3)



# FUNÇÃO MAIN

#SignInFacebook()                    # login

site = 'https://www.facebook.com/'
login = 'otaviowoiciekowski@gmail.com'
password = 'Eistein1906!'

driver = webdriver.Chrome(executable_path = r'./chromedriver.exe')              # entra com o que executa
driver.get(site)                                                                # entra com o executor

usuario = driver.find_element_by_id('email')
usuario.send_keys(login)
usuario = driver.find_element_by_id('pass')
usuario.send_keys(password)
usuario.send_keys(Keys.ENTER)
time.sleep(3)


